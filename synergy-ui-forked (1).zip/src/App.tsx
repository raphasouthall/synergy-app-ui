import * as React from "react";
import UI from "./components/UI";

export const Default = () => <UI></UI>;
